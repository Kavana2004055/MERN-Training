import React, { useEffect, useState } from 'react'
import UseEffect from './UseEffect'
function Counter() {
    const [count, setCount]=useState(0);

    useEffect(() =>{
        console.log("Count changed :", count);        
    }, [count]); //depends on count   nn
  return (
    <div>
        <h2>Count: {count}</h2>
        <button onClick={() => setCount(count +1)} >Increase</button>
        </div>
  );
}

export default Counter