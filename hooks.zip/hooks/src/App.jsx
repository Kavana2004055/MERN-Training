import React from 'react'
import UseEffect from './UseEffect'
import Counter from './Counter'
import Timer from './Timer'
import UsersList from './UsersList'
import Temperature from './Temperature'
import Greeting from './Greeting'
function App() {
  return (
    <div>
       <div>App</div>
    <UseEffect/>
    <Counter/>
    <Timer/>
    <UsersList/>
    <Greeting/>
    <Temperature value="10"/>
    </div>
   
  )
}

export default App