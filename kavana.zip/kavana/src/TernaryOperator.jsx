import React from "react";

function Pass() {
    return <h1>Congratulations!!</h1>;
}

function Fail() {
    return <h1>Better Luck Next Time</h1>;
}
function ClassResult1(props){
    const isresult=props.isresult;
    return (
        <>
        { isresult ? <Pass/> : <Fail/>
   }
            </>
    );
}
 
export default ClassResult1