import React from "react";

//level 1
function Parent1({studentName}){
    return (
        <div style={{background:"#d4f1f4",margin:"10px",padding:"10px"}}>
            <h2>Parent Component</h2>
            <Child studentName={studentName} />
        </div>      
    );
}

//level 2
function Child({studentName}){
    return(
        <div style={{background:"#a4ebf3", margin:"10px", padding:"10px"}}>
            <h3>Child Component</h3>
            <GrandChild studentName={studentName}/>
        </div>
    );
}

//level 3
function GrandChild({studentName}){
    return(
        <div style={{background:"#75e6da", margin:"10px", padding:"10px"}}>
            <h4>GrandChild Component</h4>
            <GreatGrandChild studentName={studentName} />
        </div>
    );
}

//level 4
function GreatGrandChild({studentName}){
    return (
        <div style={{background:"#189ab4ff", margin:"10px", padding:"10px"}}>
            <h5>GreatGrandChild Component</h5>
            <p>Hello <b>{studentName}</b>, this value was passed from the App component through 3 component.</p>
        </div>
    );
}


export default Parent1