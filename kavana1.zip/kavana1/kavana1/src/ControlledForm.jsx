import {useState} from "react";

function ControlledForm(){
    const [name, setName] = useState(""); //1st executes //5th executes

    const handleChange=(e) => { //4th executes
        setName(e.target.value);
    document.getElementById("result").innerText=e.target.value;
    };
     
    const handleSubmit = (e) => { //7th executes
        e.preventDefault();
        alert(`Submitted Name: ${name}`);
    };

    return (
       <div>
         <form onSubmit={handleSubmit}>
            <label>Enter your name:</label>
            <input type="text" placeholder="enter your name" value={name} onChange={handleChange} /> 
            <button type="submit">Submit</button> 
        </form>
        <p id="result"></p>
       </div>

    );
}

export default ControlledForm;