import React from 'react'
import HtmlForms from './HtmlForms'
import ControlledForm from './ControlledForm'
import TwowayBinding from './TwowayBinding'
import SimpleValidation from './SimpleValidation'

function App() {
  return (
    <div>
      <div>App</div>
     <HtmlForms/>
     <ControlledForm/>
     <TwowayBinding/>
     <SimpleValidation/>
    </div>
  )
    
}

export default App