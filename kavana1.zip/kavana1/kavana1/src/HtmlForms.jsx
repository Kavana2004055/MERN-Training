import React from 'react'

function HtmlForms() {
  return (
    <div>
        <form>
            <input type="email" id="user"/>
            <br /><br />
            <input type="password" id="user"/> <br /><br />
            <button >Submit</button>
        </form>
    </div>
  )
}

export default HtmlForms