import React, { useState } from 'react'

function SimpleValidation() {
    const [email, setEmail] =useState("");
    const [error,setError]=useState("");

    const handleSubmit=(e) =>{
        e.preventDefault();
        if(!email.includes("@")){
            alert(`Please enter a valid email`)
            setError("Please enter a valid email!");

        } else{
            setError("");
            alert(`Email Submitted: ${email}`);
        }
    };
  return (
    <form onSubmit={handleSubmit}>
        <input type="email" placeholder='enter a valid email' value={email} onChange={(e) => setEmail(e.target.value)} />
        <button type="submit">Submit</button>
        {error && <p style={{color: "red"}}> {error}</p>}
    </form>
  );
}

export default SimpleValidation