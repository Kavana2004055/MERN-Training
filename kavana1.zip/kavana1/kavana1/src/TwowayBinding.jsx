import React from "react";
import {useState} from "react";

function TwowayBinding() {
    const [message, setMessage]=useState("Hai");

    return (
        <div>
            <input type="text" placeholder="message" value={message} onChange={(e) => setMessage(e.target.value)} />
            <p>You typed: {message}</p>
        </div>
    );
}

export default TwowayBinding