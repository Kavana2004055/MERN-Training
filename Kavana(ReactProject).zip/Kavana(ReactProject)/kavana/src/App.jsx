import React from 'react'
import FirstComponent from './firstComponent'
import Fruit from './ClassComponent'
import Argument from './Argument'
import Parent from './PropsChildren'
function App() {
  return (
    <div>
      <div>App</div>
          <FirstComponent/>
         <Fruit/>
         <Argument name=" Kavana" phno=" 9876457"/>
         <Parent/>
    </div>
    
  )
}


export default App