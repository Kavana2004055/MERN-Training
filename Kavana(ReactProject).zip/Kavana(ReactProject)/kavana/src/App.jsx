import React from 'react'
import FirstComponent from './firstComponent'
import Fruit from './ClassComponent'
import Argument from './Argument'
import Parent from './PropsChildren'
import ClassResult from './ConditionalRendering'
import Car from './LogicalAnd'
import ClassResult1 from './TernaryOperator'
import Car1 from './Destructuring'
import Parent1 from './PropsDrilling'
function App() {
  return (
    <div>
      <div> <h1>App</h1></div>
          {/* <FirstComponent/>
         <Fruit/>
         <Argument name=" Kavana" phno=" 9876457"/>
         <Parent/> */}
         {/* <ClassResult isresult={false} /> */}
         <ClassResult isresult={true} />
         <Car/>

        <ClassResult1 isresult={true}/>
        <Car1 brand=" Ford " model=" Mustang " color=" red " year={1969}/>
        <Parent1 studentName="Kavana"/>

    </div>
    
  )
}


export default App